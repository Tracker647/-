create
    definer = root@localhost procedure 应付金额计算()
begin
    declare 单价 double;
    declare 订购数 int;
    declare 总金额 double;

    declare i int default 1;
    declare 订单包含_len int default 0;

    declare FOUND bool default true;
    declare priceCur cursor for select 商品单价,订购数量 from 订单包含 natural join 商品;
    declare continue handler for not found set FOUND = false;

    open priceCur;
    select count(*) from 订单包含 into 订单包含_len;
    fetch priceCur into 单价,订购数;
    while(FOUND && i <= 订单包含_len) do
            set 总金额 = 单价 * 订购数;
            update 订单包含 set 应付金额 = 总金额 where 订单包含_id = i;
            fetch priceCur into 单价,订购数;
            set i = i + 1;
        end while;
    close priceCur;
end;

