create view 支付view as
select `coms`.`支付`.`订单号` AS `订单号`, `coms`.`支付`.`发票号` AS `发票号`, sum(`coms`.`订单包含`.`应付金额`) AS `总金额`
from (`coms`.`支付`
         join `coms`.`订单包含` on ((`coms`.`支付`.`订单号` = `coms`.`订单包含`.`订单号`)))
group by `coms`.`支付`.`发票号`;

